import { expect } from 'chai';

describe('Appium DEMO App', () => {

    it('coba test aplikasinya', async () => {
        console.log('aplikasi terbuka')
        expect(true).to.equal(true);
    });

})